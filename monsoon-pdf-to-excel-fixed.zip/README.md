# Monsoon — PDF-to-Excel AI Agent

This version applies the Monsoon landing-page design language (misty green landscape, frosted-glass pill navbar, Inter typography, subtle Framer Motion animations) to the PDF-to-Excel agent. It keeps the upload, OCR, validation, preview, and Excel export functionality.

## Architecture
- `frontend/` — Vite + React 19 + TypeScript + Tailwind CSS v4 + Framer Motion.
- `backend/` — FastAPI + pdfplumber + PyMuPDF + Tesseract OCR + pandas + openpyxl.
- No paid AI API is required.
- A decorative CSS landscape is used as a graceful fallback instead of the original Monsoon stock video; the original video was not bundled. This keeps the app usable offline and preserves text readability.

## Prerequisites
- Node.js 20.19+ or 22.12+ (Vite 8 requirement)
- Python 3.11 or 3.12
- Tesseract OCR for scanned PDFs:
  - Windows: install Tesseract and add `tesseract.exe` to PATH.
  - macOS: `brew install tesseract`
  - Ubuntu/Debian: `sudo apt update && sudo apt install tesseract-ocr`

## Install
Open two terminals at the project root.

### Terminal 1 — Python backend
Windows:
```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```
macOS/Linux:
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Terminal 2 — React frontend
From the project root:
```bash
npm install
npm run dev
```
Open the Vite URL printed in the terminal, usually `http://localhost:5173`.

## Use
1. Scroll to **Try the extraction agent**.
2. Upload a PDF with 1–50 pages (up to 35 MB).
3. Keep OCR enabled if it may be scanned.
4. Customize the output column names (one per line).
5. Click **Extract & validate**.
6. Review Data Preview, Validation, and Page Text tabs.
7. Click **Download .xlsx** to create an Excel workbook with `Data`, `Validation Report`, and `Page Text` sheets.

## Notes / limitations
- This is a functional starter, not a perfect universal table understanding model. PDF table extraction depends on the document layout.
- OCR extracts text but does not always recover precise table columns from complex scans. Always review uncertain rows.
- Column mapping is rule-based. Missing fields are left blank, never fabricated.
- PDFs are processed by your local backend. Avoid exposing the backend publicly without authentication, rate limits, and privacy controls.
- The React frontend calls `/api/extract` and `/api/export`; Vite proxies those routes to the local FastAPI backend.
