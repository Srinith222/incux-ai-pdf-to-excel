import { useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowRight, CheckCircle2, CloudUpload, FileSpreadsheet, FileText, LoaderCircle, ShieldCheck, Sparkles, Table2, WandSparkles, AlertTriangle, Download, ScanText } from 'lucide-react'

const DEFAULT_COLUMNS = [
  'Invoice Number', 'Invoice Date', 'Vendor Name', 'Customer Name',
  'Item Description', 'HSN/SKU Code', 'Quantity', 'Unit Price',
  'Subtotal', 'Tax Amount', 'Total Amount', 'Source Page',
]
type Result = {
  rows: Record<string, unknown>[]
  columns: string[]
  issues: Record<string, unknown>[]
  page_text: { Page: number; 'Extracted Text': string }[]
  warnings: string[]
  pages: number
  extraction_method: string
  download_url?: string
}

const enter = { hidden: { opacity: 0, y: 18 }, visible: { opacity: 1, y: 0 } }

function App() {
  const fileRef = useRef<HTMLInputElement>(null)
  const [file, setFile] = useState<File | null>(null)
  const [columnsText, setColumnsText] = useState(DEFAULT_COLUMNS.join('\n'))
  const [ocr, setOcr] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState<Result | null>(null)
  const [tab, setTab] = useState<'data' | 'validation' | 'text'>('data')
  const [dragging, setDragging] = useState(false)

  const columns = columnsText.split('\n').map(s => s.trim()).filter(Boolean)
  const chooseFile = (picked?: File) => {
    setError('')
    setResult(null)
    if (!picked) return
    if (!picked.name.toLowerCase().endsWith('.pdf')) { setError('Please choose a PDF file.'); return }
    setFile(picked)
  }

  async function processPdf() {
    if (!file) { setError('Upload a PDF to get started.'); return }
    if (columns.length < 1) { setError('Add at least one output column.'); return }
    if (new Set(columns.map(c => c.toLowerCase())).size !== columns.length) { setError('Column names must be unique.'); return }
    setBusy(true); setError(''); setResult(null)
    try {
      const form = new FormData()
      form.append('file', file)
      form.append('columns', JSON.stringify(columns))
      form.append('use_ocr', String(ocr))
      const response = await fetch('/api/extract', { method: 'POST', body: form })
      const body = await response.json()
      if (!response.ok) throw new Error(body.detail || 'Extraction failed. Please check the PDF and try again.')
      setResult(body as Result)
      setTab('data')
      setTimeout(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not connect to the extraction service. Is the Python API running?')
    } finally { setBusy(false) }
  }

  async function downloadExcel() {
    if (!file) return
    try {
      const form = new FormData()
      form.append('file', file)
      form.append('columns', JSON.stringify(columns))
      form.append('use_ocr', String(ocr))
      const response = await fetch('/api/export', { method: 'POST', body: form })
      if (!response.ok) {
        const body = await response.json().catch(() => ({}))
        throw new Error(body.detail || 'Excel export failed.')
      }
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${file.name.replace(/\.pdf$/i, '')}_extracted.xlsx`
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Excel export failed.')
    }
  }

  const previewRows = result?.rows.slice(0, 8) ?? []
  return (
    <div className="app-shell">
      <section className="hero-scene relative min-h-[720px] overflow-hidden">
        <div className="pointer-events-none absolute inset-0 opacity-40" style={{ backgroundImage: 'radial-gradient(ellipse at 50% 42%, rgba(255,255,255,.6), transparent 54%)' }} />
        <div className="relative z-10 mx-auto flex min-h-[720px] max-w-7xl flex-col px-5 pb-10 pt-5 sm:px-8">
          <motion.header initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6, ease: 'easeOut' }} className="glass-nav mx-auto flex w-fit max-w-full items-center gap-5 rounded-full px-5 py-3 sm:gap-8 sm:px-6">
            <a href="#home" className="shrink-0 text-[16px] font-extrabold tracking-tight text-[#203c32]">Monsoon<span className="text-[#78a58d]">.</span></a>
            <nav className="hidden items-center gap-5 md:flex">
              <a className="text-[12px] font-medium text-[#47554e] transition hover:text-[#203c32]" href="#features">Features</a>
              <a className="text-[12px] font-medium text-[#47554e] transition hover:text-[#203c32]" href="#workflow">How it works</a>
              <a className="text-[12px] font-medium text-[#47554e] transition hover:text-[#203c32]" href="#extractor">Try the agent</a>
              <a className="text-[12px] font-medium text-[#47554e] transition hover:text-[#203c32]" href="#about">About</a>
            </nav>
            <a href="#extractor" className="primary-btn rounded-full px-4 py-2 text-xs font-semibold">Try it <ArrowRight className="ml-1 inline" size={13}/></a>
          </motion.header>

          <div id="home" className="flex flex-1 flex-col items-center pt-20 text-center sm:pt-24">
            <motion.span variants={enter} initial="hidden" animate="visible" transition={{ duration: .65, delay: .1 }} className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/80 bg-white/55 px-4 py-2 text-[11px] font-semibold text-[#43564b] shadow-sm backdrop-blur-lg">
              <Sparkles size={13} /> Your documents, structured intelligently
            </motion.span>
            <motion.h1 variants={enter} initial="hidden" animate="visible" transition={{ duration: .8, delay: .2 }} className="max-w-3xl text-4xl font-semibold leading-[1.06] tracking-[-.055em] text-[#1f2925] sm:text-6xl">
              Turn every PDF into <span className="text-[#537a65]">spreadsheet-ready</span> data.
            </motion.h1>
            <motion.p variants={enter} initial="hidden" animate="visible" transition={{ duration: .8, delay: .34 }} className="mt-5 max-w-xl text-sm leading-7 text-[#4e5d54] sm:text-base">
              Extract tables from digital or scanned documents, validate every row, and export a clean Excel workbook — without a paid AI API.
            </motion.p>
            <motion.div variants={enter} initial="hidden" animate="visible" transition={{ duration: .8, delay: .48 }} className="mt-7 flex flex-wrap items-center justify-center gap-3">
              <motion.a whileHover={{ scale: 1.04 }} whileTap={{ scale: .97 }} href="#extractor" className="primary-btn rounded-xl px-6 py-3 text-sm font-semibold">Start extracting <ArrowRight className="ml-2 inline" size={15}/></motion.a>
              <motion.a whileHover={{ scale: 1.04, backgroundColor: 'rgba(255,255,255,.92)' }} whileTap={{ scale: .97 }} href="#workflow" className="secondary-btn rounded-xl px-6 py-3 text-sm font-semibold">See how it works <ArrowDown className="ml-2 inline" size={15}/></motion.a>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8, delay: .62 }} className="mt-12 grid w-full max-w-3xl grid-cols-1 gap-3 sm:grid-cols-3">
              {[{icon:FileText,title:'Up to 50 pages',desc:'Process longer PDFs'},{icon:ScanText,title:'OCR ready',desc:'Support scanned documents'},{icon:ShieldCheck,title:'Validated output',desc:'Review issues before export'}].map(item => <div key={item.title} className="flex items-center gap-3 rounded-2xl border border-white/70 bg-white/45 p-4 text-left backdrop-blur-lg"><div className="rounded-xl bg-white/70 p-2.5 text-[#416b55]"><item.icon size={20}/></div><div><p className="text-sm font-semibold text-[#26372d]">{item.title}</p><p className="mt-1 text-xs text-[#637168]">{item.desc}</p></div></div>)}
            </motion.div>
          </div>
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .7 }} className="pt-12 text-center">
            <p className="mb-4 text-[10px] font-semibold uppercase tracking-[.22em] text-[#5f7467]">Built for real-world documents</p>
            <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-3 text-sm font-bold tracking-wide text-[#5a7564]/80"><span>INVOICES</span><span>REPORTS</span><span>STATEMENTS</span><span>INVENTORY</span><span>RECEIPTS</span></div>
          </motion.div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={enter} transition={{ duration: .6 }} className="mb-10 max-w-2xl">
          <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#60816d]">Designed for messy documents</p>
          <h2 className="text-3xl font-semibold tracking-[-.04em] text-[#203c32] sm:text-4xl">From document chaos to structured data.</h2>
          <p className="mt-4 text-sm leading-7 text-[#617067]">A practical extraction workflow that keeps your data reviewable, traceable, and ready for Excel.</p>
        </motion.div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[{icon:Table2,title:'Table extraction',desc:'Capture rows from text-based PDFs and join table data across pages.'},{icon:ScanText,title:'Scanned PDF OCR',desc:'Use local Tesseract OCR when a page has little or no selectable text.'},{icon:ShieldCheck,title:'Data validation',desc:'Flag invalid numbers, duplicate rows, missing values and mismatched totals.'},{icon:FileSpreadsheet,title:'Excel export',desc:'Download a workbook with data, validation findings and extracted page text.'}].map((f,i) => <motion.article key={f.title} initial="hidden" whileInView="visible" viewport={{ once:true }} variants={enter} transition={{ duration:.5, delay:i*.08 }} className="surface rounded-2xl p-5"><div className="mb-5 inline-flex rounded-xl bg-[#e5eee8] p-3 text-[#416b55]"><f.icon size={21}/></div><h3 className="text-base font-semibold text-[#203c32]">{f.title}</h3><p className="mt-2 text-sm leading-6 text-[#68766e]">{f.desc}</p></motion.article>)}
        </div>
      </section>

      <section id="workflow" className="border-y border-[#d9e4dc] bg-white/35 py-16">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="mb-8 text-center"><p className="text-xs font-bold uppercase tracking-[.2em] text-[#60816d]">Simple workflow</p><h2 className="mt-3 text-3xl font-semibold tracking-[-.04em] text-[#203c32]">Four steps to a cleaner spreadsheet</h2></div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[['01','Upload','Choose a PDF with up to 50 pages.'],['02','Extract','Read tables and OCR scanned pages.'],['03','Review','Inspect rows and validation warnings.'],['04','Export','Download your Excel workbook.']].map(([n,title,desc]) => <div key={n} className="flex gap-4 rounded-2xl border border-white bg-white/65 p-5"><span className="text-lg font-semibold text-[#8aab96]">{n}</span><div><h3 className="font-semibold text-[#203c32]">{title}</h3><p className="mt-1 text-sm leading-6 text-[#68766e]">{desc}</p></div></div>)}
          </div>
        </div>
      </section>

      <section id="extractor" className="mx-auto max-w-7xl scroll-mt-8 px-5 py-20 sm:px-8">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div><p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#60816d]">Live workspace</p><h2 className="text-3xl font-semibold tracking-[-.04em] text-[#203c32] sm:text-4xl">Try the extraction agent</h2><p className="mt-3 max-w-xl text-sm leading-7 text-[#617067]">Upload your document, customize the output schema, and inspect the extracted data before downloading.</p></div>
          <div className="flex items-center gap-2 rounded-full border border-[#d5e2d9] bg-white/60 px-4 py-2 text-xs font-medium text-[#55705f]"><span className="h-2 w-2 rounded-full bg-[#5a9b72]"/>{'Local-first processing'}</div>
        </div>
        <div className="grid items-start gap-5 lg:grid-cols-[.85fr_1.15fr]">
          <div className="surface rounded-3xl p-5 sm:p-7">
            <h3 className="flex items-center gap-2 text-lg font-semibold text-[#203c32]"><CloudUpload size={20}/> Upload & configure</h3>
            <p className="mt-2 text-sm leading-6 text-[#68766e]">Choose a PDF (maximum 50 pages) and set the columns you want in Excel.</p>
            <input ref={fileRef} type="file" accept="application/pdf,.pdf" className="hidden" onChange={e => chooseFile(e.target.files?.[0])}/>
            <button onClick={() => fileRef.current?.click()} onDragOver={e => {e.preventDefault();setDragging(true)}} onDragLeave={() => setDragging(false)} onDrop={e => {e.preventDefault();setDragging(false);chooseFile(e.dataTransfer.files?.[0])}} className={`mt-5 flex w-full flex-col items-center rounded-2xl border border-dashed px-4 py-8 text-center transition ${dragging?'border-[#507b61] bg-[#e5eee8]':'border-[#b8cbbd] bg-white/55 hover:bg-white/85'}`}>
              <div className="rounded-2xl bg-[#e5eee8] p-3 text-[#416b55]"><FileText size={24}/></div>
              <span className="mt-3 text-sm font-semibold text-[#2a4134]">{file ? file.name : 'Choose a PDF to upload'}</span>
              <span className="mt-1 text-xs text-[#748178]">{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · PDF` : 'Click to browse or drag and drop · up to 50 pages'}</span>
            </button>
            <label className="mt-5 flex cursor-pointer items-center justify-between rounded-xl bg-white/55 p-3"><span><span className="block text-sm font-semibold text-[#2a4134]">Enable OCR</span><span className="mt-1 block text-xs text-[#748178]">For scanned pages (Tesseract required)</span></span><input type="checkbox" checked={ocr} onChange={e => setOcr(e.target.checked)} className="h-4 w-4 accent-[#315744]"/></label>
            <label className="mt-5 block text-sm font-semibold text-[#2a4134]">Output columns <span className="font-normal text-[#748178]">(one per line)</span></label>
            <textarea value={columnsText} onChange={e => setColumnsText(e.target.value)} rows={8} className="mt-2 w-full rounded-xl border border-[#d7e2da] bg-white/70 p-3 font-mono text-xs leading-5 text-[#3e5145] outline-none transition focus:border-[#769a82] focus:ring-2 focus:ring-[#c6dfce]" />
            <p className="mt-2 text-xs text-[#748178]">{columns.length} output columns · Missing fields remain blank instead of being invented.</p>
            {error && <div role="alert" className="mt-4 flex gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700"><AlertTriangle size={18} className="shrink-0"/>{error}</div>}
            <motion.button whileHover={{ scale: busy ? 1 : 1.01 }} whileTap={{ scale: busy ? 1 : .98 }} disabled={busy || !file} onClick={processPdf} className="primary-btn mt-5 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3.5 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50">{busy ? <><LoaderCircle className="animate-spin" size={17}/> Processing document...</> : <><WandSparkles size={17}/> Extract & validate</>}</motion.button>
            <p className="mt-3 text-center text-[11px] leading-5 text-[#87938b]">The Python API must be running locally. No paid AI API is required.</p>
          </div>

          <div id="results" className="surface min-h-[490px] scroll-mt-6 rounded-3xl p-5 sm:p-7">
            {!result ? <div className="flex min-h-[440px] flex-col items-center justify-center text-center"><div className="rounded-3xl bg-[#e5eee8] p-5 text-[#416b55]"><FileSpreadsheet size={34}/></div><h3 className="mt-5 text-lg font-semibold text-[#203c32]">Your results will appear here</h3><p className="mt-2 max-w-sm text-sm leading-6 text-[#748178]">After extraction, preview the rows, review validation issues, and export your workbook.</p><div className="mt-6 flex flex-wrap justify-center gap-2"><span className="rounded-full bg-white/80 px-3 py-1.5 text-xs text-[#5c7564]">Data preview</span><span className="rounded-full bg-white/80 px-3 py-1.5 text-xs text-[#5c7564]">Validation report</span><span className="rounded-full bg-white/80 px-3 py-1.5 text-xs text-[#5c7564]">Page text</span></div></div> :
            <div>
              <div className="flex flex-wrap items-start justify-between gap-4"><div><h3 className="text-lg font-semibold text-[#203c32]">Extraction results</h3><p className="mt-1 text-xs text-[#748178]">{result.pages} pages · {result.extraction_method}</p></div><button onClick={downloadExcel} className="primary-btn rounded-xl px-4 py-2.5 text-xs font-semibold"><Download className="mr-2 inline" size={14}/>Download .xlsx</button></div>
              <div className="mt-5 grid grid-cols-3 gap-2"><div className="rounded-xl bg-white/75 p-3"><p className="text-[11px] text-[#748178]">Pages</p><p className="mt-1 text-2xl font-semibold text-[#203c32]">{result.pages}</p></div><div className="rounded-xl bg-white/75 p-3"><p className="text-[11px] text-[#748178]">Rows</p><p className="mt-1 text-2xl font-semibold text-[#203c32]">{result.rows.length}</p></div><div className="rounded-xl bg-white/75 p-3"><p className="text-[11px] text-[#748178]">Issues</p><p className="mt-1 text-2xl font-semibold text-[#a75b2b]">{result.issues.length}</p></div></div>
              <div className="mt-5 flex flex-wrap gap-2 border-b border-[#dbe5de] pb-3">{(['data','validation','text'] as const).map(t => <button key={t} onClick={() => setTab(t)} className={`rounded-full px-3 py-2 text-xs font-semibold capitalize ${tab===t?'bg-[#203c32] text-white':'bg-white/70 text-[#5c7564] hover:bg-white'}`}>{t==='data'?'Data preview':t==='validation'?'Validation':'Page text'}</button>)}</div>
              {tab==='data' && <div className="mt-4 overflow-x-auto rounded-xl border border-[#e0e8e2] bg-white/70"><table className="w-full min-w-[500px] border-collapse text-left text-xs"><thead className="bg-[#e7efe9]"><tr>{result.columns.slice(0,5).map(c=><th key={c} className="px-3 py-3 font-semibold text-[#3d5747]">{c}</th>)}</tr></thead><tbody>{previewRows.map((row,i)=><tr key={i} className="border-t border-[#e8eee9]">{result.columns.slice(0,5).map(c=><td key={c} className="max-w-[180px] truncate px-3 py-3 text-[#536359]">{String(row[c] ?? '') || '—'}</td>)}</tr>)}</tbody></table>{result.rows.length>8&&<p className="px-3 py-2 text-[11px] text-[#748178]">Showing first 8 of {result.rows.length} rows. Full data is included in Excel.</p>}</div>}
              {tab==='validation' && <div className="mt-4 max-h-[300px] overflow-auto">{result.issues.length ? <div className="space-y-2">{result.issues.slice(0,30).map((issue,i)=><div key={i} className="rounded-xl border border-[#ead9c8] bg-[#fff9f1] p-3"><p className="text-xs font-semibold text-[#8d5428]">Row {String(issue.Row ?? '')} · {String(issue.Column ?? '')}</p><p className="mt-1 text-xs text-[#7a6b5c]">{String(issue.Issue ?? '')}</p></div>)}</div>:<div className="rounded-xl bg-[#e8f4eb] p-4 text-sm text-[#376449]"><CheckCircle2 className="mr-2 inline" size={17}/>No issues detected by current validation rules.</div>}</div>}
              {tab==='text' && <div className="mt-4 max-h-[300px] space-y-2 overflow-auto">{result.page_text.map(p=><div key={p.Page} className="rounded-xl bg-white/70 p-3"><p className="text-xs font-semibold text-[#416b55]">Page {p.Page}</p><p className="mt-2 whitespace-pre-wrap text-xs leading-5 text-[#617067]">{p['Extracted Text'] || '(No text extracted)'}</p></div>)}</div>}
              {result.warnings.length>0 && <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-800">{result.warnings.map((w,i)=><p key={i}>• {w}</p>)}</div>}
            </div>}
          </div>
        </div>
      </section>

      <section id="about" className="mx-auto max-w-7xl px-5 pb-16 sm:px-8"><div className="flex flex-col justify-between gap-4 rounded-3xl bg-[#203c32] p-7 text-white sm:flex-row sm:items-center sm:p-10"><div><p className="text-xs font-semibold uppercase tracking-[.2em] text-[#b5d3c0]">Ready for your next document?</p><h2 className="mt-3 text-2xl font-semibold tracking-tight">Less copying. More clarity.</h2><p className="mt-2 max-w-xl text-sm leading-6 text-white/70">Review extracted data before you trust it. Your PDF-to-Excel workflow, with transparency built in.</p></div><a href="#extractor" className="inline-flex w-fit items-center rounded-xl bg-white px-5 py-3 text-sm font-semibold text-[#203c32] transition hover:bg-[#e8f0eb]">Open workspace <ArrowRight className="ml-2" size={16}/></a></div></section>
      <footer className="border-t border-[#dbe5de] px-5 py-6 text-center text-xs text-[#7c8a80]">Monsoon · PDF-to-Excel Agent <span className="mx-2">•</span> Local-first document processing</footer>
    </div>
  )
}
export default App
