from __future__ import annotations

import io
import json
import re
from typing import Any

import fitz
import pandas as pd
import pdfplumber
import pytesseract
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from PIL import Image

app = FastAPI(title="Monsoon PDF-to-Excel API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
MAX_BYTES = 35 * 1024 * 1024
NUMERIC_FIELDS = {"quantity", "unit price", "subtotal", "tax amount", "total amount", "amount", "debit", "credit", "balance", "price", "tax", "qty"}


def normalise(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def parse_number(value: Any) -> float | None:
    text = normalise(value)
    if not text:
        return None
    text = text.replace(",", "").replace("₹", "").replace("$", "").replace("€", "").replace("£", "").replace("%", "").strip()
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    text = re.sub(r"^[^\d+\-.]*", "", text)
    text = re.sub(r"[^\d.\-+]", "", text)
    if text in {"", "-", "+", ".", "-.", "+."}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def count_pages(pdf_bytes: bytes) -> int:
    try:
        with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
            return doc.page_count
    except Exception as exc:
        raise HTTPException(400, "The uploaded file is not a readable PDF.") from exc


def extract_pages(pdf_bytes: bytes, use_ocr: bool) -> tuple[list[dict], list[str]]:
    records, warnings = [], []
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for idx, page in enumerate(pdf.pages):
                text = page.extract_text() or ""
                tables = []
                try:
                    tables = page.extract_tables() or []
                except Exception as exc:
                    warnings.append(f"Page {idx + 1}: table extraction issue ({exc.__class__.__name__}).")
                if use_ocr and len(text.strip()) < 35:
                    try:
                        with fitz.open(stream=pdf_bytes, filetype="pdf") as doc:
                            p = doc.load_page(idx)
                            pix = p.get_pixmap(matrix=fitz.Matrix(220 / 72, 220 / 72), alpha=False)
                            image = Image.open(io.BytesIO(pix.tobytes("png")))
                        text = pytesseract.image_to_string(image, lang="eng")
                    except pytesseract.TesseractNotFoundError:
                        warnings.append(f"Page {idx + 1}: Tesseract was not found. Install Tesseract OCR to process scanned pages.")
                    except Exception as exc:
                        warnings.append(f"Page {idx + 1}: OCR failed ({exc.__class__.__name__}).")
                records.append({"page": idx + 1, "text": text, "tables": tables})
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, f"Could not read the PDF ({exc.__class__.__name__}). It may be damaged or password-protected.") from exc
    return records, warnings


def table_to_records(page_records: list[dict]) -> list[dict]:
    out = []
    canonical_headers: list[str] | None = None
    for page in page_records:
        for table in page["tables"]:
            rows = [[normalise(c) for c in row] for row in table if row and any(normalise(c) for c in row)]
            if not rows:
                continue
            width = max(map(len, rows))
            rows = [row + [""] * (width - len(row)) for row in rows]
            first = rows[0]
            header_like = sum(bool(re.search(r"[A-Za-z]", c)) for c in first) >= max(2, width // 2)
            if header_like:
                headers = [c or f"Column {i+1}" for i, c in enumerate(first)]
                body = rows[1:]
                if canonical_headers is None:
                    canonical_headers = headers
                for row in body:
                    if [c.lower() for c in row] == [c.lower() for c in headers]:
                        continue
                    item = dict(zip(headers, row))
                    item["Source Page"] = page["page"]
                    out.append(item)
            else:
                headers = (canonical_headers or [f"Column {i+1}" for i in range(width)])
                headers = (headers + [f"Column {i+1}" for i in range(len(headers), width)])[:width]
                for row in rows:
                    item = dict(zip(headers, row))
                    item["Source Page"] = page["page"]
                    out.append(item)
    return out


def text_fallback(page_records: list[dict]) -> list[dict]:
    out = []
    for page in page_records:
        for line in page["text"].splitlines():
            line = normalise(line)
            if not line:
                continue
            parts = [normalise(p) for p in re.split(r"\s{2,}|\s*\|\s*", line) if normalise(p)]
            if len(parts) >= 2:
                row = {f"Column {i+1}": value for i, value in enumerate(parts)}
                row["Source Page"] = page["page"]
                out.append(row)
    return out


def map_schema(records: list[dict], columns: list[str]) -> pd.DataFrame:
    df = pd.DataFrame(records).fillna("") if records else pd.DataFrame()
    result = pd.DataFrame(index=df.index)
    sources = {str(c).strip().lower(): c for c in df.columns}
    for target in columns:
        key = target.lower()
        if key in sources:
            result[target] = df[sources[key]]
        else:
            candidates = [s for s in df.columns if key in str(s).lower() or str(s).lower() in key]
            result[target] = df[candidates[0]] if candidates else ""
    return result.fillna("")


def validate(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    clean = df.copy()
    issues = []
    for col in clean.columns:
        if any(token in col.lower() for token in NUMERIC_FIELDS):
            parsed = clean[col].map(parse_number)
            invalid = clean[col].map(normalise).ne("") & parsed.isna()
            for idx in clean.index[invalid]:
                issues.append({"Row": int(idx) + 2, "Column": col, "Value": clean.at[idx, col], "Issue": "Expected a numeric value", "Severity": "Review"})
            clean[col] = parsed.where(parsed.notna(), clean[col])
    blank = clean.apply(lambda row: all(normalise(v) == "" for v in row), axis=1) if len(clean) else pd.Series(dtype=bool)
    for idx in clean.index[blank]:
        issues.append({"Row": int(idx) + 2, "Column": "*", "Value": "", "Issue": "Empty row", "Severity": "Review"})
    nonblank = clean.loc[~blank] if len(clean) else clean
    if len(nonblank):
        dup = nonblank.astype(str).duplicated()
        for idx in nonblank.index[dup]:
            issues.append({"Row": int(idx) + 2, "Column": "*", "Value": "", "Issue": "Duplicate row", "Severity": "Review"})
    lower = {c.lower(): c for c in clean.columns}
    sub = next((lower[k] for k in lower if "subtotal" in k), None)
    tax = next((lower[k] for k in lower if "tax" in k and "amount" in k), None)
    total = next((lower[k] for k in lower if "total" in k and "amount" in k), None)
    if sub and tax and total:
        for idx in clean.index:
            a, b, c = parse_number(clean.at[idx, sub]), parse_number(clean.at[idx, tax]), parse_number(clean.at[idx, total])
            if a is not None and b is not None and c is not None and abs(a + b - c) > .05:
                issues.append({"Row": int(idx) + 2, "Column": total, "Value": c, "Issue": "Subtotal + tax does not match total", "Severity": "Check"})
    return clean, pd.DataFrame(issues, columns=["Row", "Column", "Value", "Issue", "Severity"])


def run_extraction(pdf_bytes: bytes, columns: list[str], use_ocr: bool) -> tuple[dict, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pages = count_pages(pdf_bytes)
    if pages < 1:
        raise HTTPException(400, "This PDF contains no pages.")
    if pages > 50:
        raise HTTPException(413, f"This PDF has {pages} pages. The limit is 50 pages.")
    page_records, warnings = extract_pages(pdf_bytes, use_ocr)
    records = table_to_records(page_records)
    method = "Detected tables"
    if not records:
        records = text_fallback(page_records)
        method = "Text fallback (no tables detected)"
    if not records:
        warnings.append("No structured rows were detected. Try a clearer PDF or check the OCR installation.")
    data = map_schema(records, columns)
    clean, issues = validate(data)
    page_text = pd.DataFrame([{"Page": p["page"], "Extracted Text": p["text"]} for p in page_records])
    response = {
        "rows": clean.where(pd.notna(clean), None).to_dict(orient="records"),
        "columns": list(clean.columns),
        "issues": issues.where(pd.notna(issues), None).to_dict(orient="records"),
        "page_text": page_text.where(pd.notna(page_text), None).to_dict(orient="records"),
        "warnings": warnings,
        "pages": pages,
        "extraction_method": method,
    }
    return response, clean, issues, page_text


def workbook_bytes(data: pd.DataFrame, issues: pd.DataFrame, page_text: pd.DataFrame) -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        data.to_excel(writer, sheet_name="Data", index=False)
        issues.to_excel(writer, sheet_name="Validation Report", index=False)
        page_text.to_excel(writer, sheet_name="Page Text", index=False)
    output.seek(0)
    wb = load_workbook(output)
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="203C32")
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        for cells in ws.columns:
            max_len = max((len(str(cell.value or "")) for cell in cells[:150]), default=10)
            ws.column_dimensions[get_column_letter(cells[0].column)].width = min(max(max_len + 2, 12), 42)
        ws.row_dimensions[1].height = 28
    final = io.BytesIO()
    wb.save(final)
    return final.getvalue()


async def read_request(file: UploadFile, columns: str, use_ocr: bool):
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(400, "Upload a PDF file.")
    pdf_bytes = await file.read()
    if not pdf_bytes:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(pdf_bytes) > MAX_BYTES:
        raise HTTPException(413, "The PDF is larger than the 35 MB upload limit.")
    try:
        parsed = json.loads(columns)
        if not isinstance(parsed, list) or not all(isinstance(c, str) and c.strip() for c in parsed):
            raise ValueError()
        parsed = list(dict.fromkeys(c.strip() for c in parsed))
        if not parsed:
            raise ValueError()
    except (json.JSONDecodeError, ValueError):
        raise HTTPException(400, "Columns must be a JSON list of non-empty names.")
    return pdf_bytes, parsed, use_ocr


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/extract")
async def extract(file: UploadFile = File(...), columns: str = Form(...), use_ocr: bool = Form(True)):
    pdf_bytes, parsed_columns, ocr = await read_request(file, columns, use_ocr)
    response, _, _, _ = run_extraction(pdf_bytes, parsed_columns, ocr)
    return response


@app.post("/api/export")
async def export(file: UploadFile = File(...), columns: str = Form(...), use_ocr: bool = Form(True)):
    pdf_bytes, parsed_columns, ocr = await read_request(file, columns, use_ocr)
    _, data, issues, page_text = run_extraction(pdf_bytes, parsed_columns, ocr)
    content = workbook_bytes(data, issues, page_text)
    name = (file.filename or "document.pdf").rsplit(".", 1)[0]
    headers = {"Content-Disposition": f'attachment; filename="{name}_extracted.xlsx"'}
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers=headers)
